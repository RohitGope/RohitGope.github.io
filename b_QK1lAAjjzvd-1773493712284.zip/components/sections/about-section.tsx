"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { GraduationCap, Target, Search, FileCheck } from "lucide-react"

const skills = [
  { icon: Target, label: "Problem Solving", description: "Systematic approach to identifying and resolving issues" },
  { icon: Search, label: "Attention to Detail", description: "Meticulous analysis of logs and security events" },
  { icon: FileCheck, label: "Risk Analysis", description: "Evaluating threats and prioritizing responses" },
  { icon: GraduationCap, label: "Continuous Learning", description: "Always expanding cybersecurity knowledge" },
]

export function AboutSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="about"
      className="py-20 md:py-32 relative overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Section header */}
          <div
            className={`text-center mb-16 transition-all duration-700 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              About <span className="text-primary">Me</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
          </div>

          {/* Bio content */}
          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            {/* Photo placeholder */}
            <div
              className={`transition-all duration-700 delay-200 ${
                isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
              }`}
            >
              <div className="relative group">
                <div className="aspect-square rounded-2xl bg-gradient-to-br from-card to-secondary overflow-hidden border border-border group-hover:border-primary/50 transition-colors">
                  <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                    <div className="text-center p-8">
                      <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-5xl font-bold text-primary">RG</span>
                      </div>
                      <p className="text-sm text-muted-foreground">Professional Photo</p>
                    </div>
                  </div>
                </div>
                {/* Decorative border */}
                <div className="absolute -inset-1 bg-gradient-to-r from-neon-green via-neon-lime to-neon-cyan rounded-2xl opacity-20 blur group-hover:opacity-40 transition-opacity -z-10" />
              </div>
            </div>

            {/* Bio text */}
            <div
              className={`transition-all duration-700 delay-400 ${
                isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
              }`}
            >
              <h3 className="text-2xl font-semibold mb-4">
                Rohit Gope
              </h3>
              <p className="text-muted-foreground mb-4 leading-relaxed">
                A BCA graduate from Arka Jain University (2024) with a strong foundation in 
                Quality Assurance, now transitioning into the dynamic field of cybersecurity 
                as a SOC Analyst.
              </p>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                My QA background has equipped me with the analytical mindset and attention 
                to detail essential for identifying security threats, analyzing incidents, 
                and implementing robust defense strategies.
              </p>
              
              {/* Quick stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-card border border-border">
                  <p className="text-2xl font-bold text-primary">2024</p>
                  <p className="text-sm text-muted-foreground">BCA Graduate</p>
                </div>
                <div className="p-4 rounded-lg bg-card border border-border">
                  <p className="text-2xl font-bold text-accent">Security+</p>
                  <p className="text-sm text-muted-foreground">Certified</p>
                </div>
              </div>
            </div>
          </div>

          {/* Transferable skills */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {skills.map((skill, index) => (
              <Card
                key={skill.label}
                className={`group bg-card/50 border-border hover:border-primary/50 transition-all duration-500 hover:-translate-y-1 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${600 + index * 100}ms` }}
              >
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <skill.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h4 className="font-semibold mb-2">{skill.label}</h4>
                  <p className="text-sm text-muted-foreground">{skill.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
