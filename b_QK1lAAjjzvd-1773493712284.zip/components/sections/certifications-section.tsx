"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Award,
  GraduationCap,
  BookOpen,
  Trophy,
  Target,
  Flame,
} from "lucide-react"

const certifications = [
  {
    id: "security-plus",
    title: "CompTIA Security+",
    issuer: "CompTIA",
    year: "2024",
    icon: Award,
    color: "primary",
    featured: true,
  },
  {
    id: "python",
    title: "Python Programming",
    issuer: "New Horizon",
    year: "2024",
    icon: Trophy,
    color: "accent",
    featured: false,
  },
  {
    id: "excel",
    title: "Advanced Excel",
    issuer: "STP Computer Education",
    year: "2024",
    icon: GraduationCap,
    color: "cyan",
    featured: false,
  },
]

const ongoingTraining = [
  {
    platform: "TryHackMe",
    progress: 75,
    description: "Hands-on cybersecurity training through gamified rooms",
    icon: Target,
  },
  {
    platform: "HackTheBox",
    progress: 45,
    description: "Advanced penetration testing challenges",
    icon: Flame,
  },
  {
    platform: "Coursera",
    progress: 60,
    description: "Google Cybersecurity Certificate",
    icon: BookOpen,
  },
]

const timeline = [
  { year: "2024", event: "BCA Graduation", type: "education" },
  { year: "2024", event: "QA Experience", type: "work" },
  { year: "2024", event: "Security+ Certification", type: "cert" },
  { year: "2025", event: "SOC Analyst", type: "goal" },
]

const colorClasses = {
  primary: {
    bg: "bg-primary/10",
    text: "text-primary",
    border: "border-primary/30",
    glow: "shadow-[0_0_15px_rgba(74,222,128,0.4)]",
  },
  accent: {
    bg: "bg-accent/10",
    text: "text-accent",
    border: "border-accent/30",
    glow: "shadow-[0_0_15px_rgba(132,204,22,0.4)]",
  },
  cyan: {
    bg: "bg-neon-cyan/10",
    text: "text-neon-cyan",
    border: "border-neon-cyan/30",
    glow: "shadow-[0_0_15px_rgba(34,211,238,0.4)]",
  },
}

export function CertificationsSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [hoveredCert, setHoveredCert] = useState<string | null>(null)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="certifications"
      className="py-20 md:py-32 bg-secondary/30 relative overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,var(--neon-green)_0%,transparent_50%)] opacity-5" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Certifications & <span className="text-primary">Learning</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Timeline */}
          <div
            className={`mb-16 transition-all duration-700 delay-200 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <div className="relative">
              {/* Progress bar background */}
              <div className="absolute top-1/2 left-0 right-0 h-1 bg-border -translate-y-1/2" />
              
              {/* Animated progress */}
              <div 
                className="absolute top-1/2 left-0 h-1 bg-gradient-to-r from-neon-green via-neon-lime to-neon-cyan -translate-y-1/2 transition-all duration-1000"
                style={{ width: isVisible ? "75%" : "0%" }}
              />

              {/* Timeline points */}
              <div className="relative flex justify-between">
                {timeline.map((item, index) => (
                  <div
                    key={item.event}
                    className={`flex flex-col items-center transition-all duration-500 ${
                      isVisible ? "opacity-100" : "opacity-0"
                    }`}
                    style={{ transitionDelay: `${300 + index * 150}ms` }}
                  >
                    <div
                      className={`w-4 h-4 rounded-full mb-2 ${
                        item.type === "goal"
                          ? "bg-muted-foreground animate-pulse"
                          : "bg-primary"
                      }`}
                    />
                    <span className="text-sm font-semibold">{item.year}</span>
                    <span className="text-xs text-muted-foreground text-center max-w-[80px]">
                      {item.event}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Certifications grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-16">
            {certifications.map((cert, index) => {
              const colors = colorClasses[cert.color as keyof typeof colorClasses]
              return (
                <Card
                  key={cert.id}
                  className={`group bg-card/50 border-border transition-all duration-500 hover:-translate-y-2 ${
                    hoveredCert === cert.id ? colors.glow : ""
                  } ${
                    isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                  }`}
                  style={{ transitionDelay: `${400 + index * 100}ms` }}
                  onMouseEnter={() => setHoveredCert(cert.id)}
                  onMouseLeave={() => setHoveredCert(null)}
                >
                  <CardContent className="p-6 text-center">
                    <div
                      className={`w-16 h-16 mx-auto mb-4 rounded-full ${colors.bg} flex items-center justify-center transition-all duration-300 group-hover:scale-110`}
                    >
                      <cert.icon className={`w-8 h-8 ${colors.text}`} />
                    </div>
                    {cert.featured && (
                      <Badge className="mb-2 bg-primary/20 text-primary border-0">
                        Featured
                      </Badge>
                    )}
                    <h3 className="font-bold text-lg mb-1">{cert.title}</h3>
                    <p className="text-sm text-muted-foreground mb-1">
                      {cert.issuer}
                    </p>
                    <p className={`text-sm font-semibold ${colors.text}`}>
                      {cert.year}
                    </p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Ongoing training */}
          <div
            className={`transition-all duration-700 delay-600 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <h3 className="text-xl font-semibold mb-6 text-center">
              Ongoing Training
            </h3>
            <div className="grid md:grid-cols-3 gap-6">
              {ongoingTraining.map((training, index) => (
                <Card
                  key={training.platform}
                  className="bg-card/50 border-border hover:border-primary/30 transition-all duration-300"
                  style={{ transitionDelay: `${700 + index * 100}ms` }}
                >
                  <CardContent className="p-5">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <training.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{training.platform}</h4>
                        <p className="text-xs text-muted-foreground">
                          {training.description}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Progress value={training.progress} className="flex-1 h-2" />
                      <span className="text-sm font-mono text-primary">
                        {training.progress}%
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
