"use client"

import { useEffect, useState } from "react"
import { NetworkBackground } from "@/components/network-background"
import { TypewriterText } from "@/components/typewriter-text"
import { Button } from "@/components/ui/button"
import { ChevronDown, Shield } from "lucide-react"

export function HeroSection() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Animated background */}
      <NetworkBackground />
      
      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/80 to-background" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div
          className={`transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          {/* Shield icon */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Shield className="w-16 h-16 text-primary animate-float" />
              <div className="absolute inset-0 w-16 h-16 bg-primary/20 blur-xl rounded-full animate-pulse-glow" />
            </div>
          </div>

          {/* Main headline with typewriter effect */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-balance">
            <TypewriterText 
              text="QA Specialist → SOC Analyst" 
              delay={80}
              className="bg-gradient-to-r from-neon-green via-neon-lime to-neon-cyan bg-clip-text text-transparent"
            />
          </h1>

          {/* Subheadline */}
          <p
            className={`text-lg md:text-xl lg:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto transition-all duration-1000 delay-500 text-balance ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            Leveraging QA precision to defend against cyber threats
          </p>

          {/* Name tag */}
          <p
            className={`text-sm md:text-base text-primary mb-8 font-mono transition-all duration-1000 delay-700 ${
              isVisible ? "opacity-100" : "opacity-0"
            }`}
          >
            {'// Rohit Gope - Cybersecurity Professional'}
          </p>

          {/* CTA Button */}
          <div
            className={`transition-all duration-1000 delay-1000 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <Button
              size="lg"
              className="group relative overflow-hidden bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 neon-border"
              onClick={() => {
                document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })
              }}
            >
              <span className="relative z-10">View My Work</span>
              <div className="absolute inset-0 bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_100%] animate-[shimmer_2s_infinite] opacity-0 group-hover:opacity-30 transition-opacity" />
            </Button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div
          className={`absolute bottom-8 left-1/2 -translate-x-1/2 transition-all duration-1000 delay-1500 ${
            isVisible ? "opacity-100" : "opacity-0"
          }`}
        >
          <ChevronDown className="w-8 h-8 text-primary animate-bounce" />
        </div>
      </div>
    </section>
  )
}
