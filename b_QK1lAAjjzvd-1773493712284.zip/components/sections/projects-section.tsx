"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github, Activity, Network, Shield, Terminal } from "lucide-react"

type ProjectCategory = "all" | "labs" | "scripts" | "analysis"

interface Project {
  id: string
  title: string
  description: string
  category: ProjectCategory
  tags: string[]
  icon: typeof Activity
  color: "primary" | "accent" | "purple"
}

const projects: Project[] = [
  {
    id: "splunk-dashboard",
    title: "Splunk Security Dashboard",
    description: "Custom SIEM dashboard for real-time log monitoring, threat detection, and security event visualization with automated alerting capabilities.",
    category: "labs",
    tags: ["Splunk", "SIEM", "Log Analysis"],
    icon: Activity,
    color: "primary",
  },
  {
    id: "wireshark-analysis",
    title: "Wireshark Packet Analysis",
    description: "Deep packet inspection project analyzing network traffic patterns, identifying anomalies, and documenting potential security threats.",
    category: "analysis",
    tags: ["Wireshark", "Network", "Packet Analysis"],
    icon: Network,
    color: "accent",
  },
  {
    id: "vulnerability-scan",
    title: "Vulnerability Assessment Lab",
    description: "Comprehensive vulnerability scanning using Nessus and OpenVAS, with detailed reporting and remediation recommendations.",
    category: "labs",
    tags: ["Nessus", "OpenVAS", "Security Scanning"],
    icon: Shield,
    color: "cyan",
  },
  {
    id: "python-automation",
    title: "Python Security Automation",
    description: "Collection of Python scripts for automating security tasks including log parsing, threat intel gathering, and incident response workflows.",
    category: "scripts",
    tags: ["Python", "Automation", "Scripts"],
    icon: Terminal,
    color: "primary",
  },
  {
    id: "soc-playbook",
    title: "SOC Playbook Templates",
    description: "Standardized incident response playbooks for common security scenarios including phishing, malware, and unauthorized access attempts.",
    category: "labs",
    tags: ["IR", "Playbooks", "Documentation"],
    icon: Activity,
    color: "accent",
  },
  {
    id: "log-parser",
    title: "Security Log Parser",
    description: "Custom Python tool for parsing and correlating logs from multiple sources to identify potential security incidents.",
    category: "scripts",
    tags: ["Python", "Logs", "Correlation"],
    icon: Terminal,
    color: "cyan",
  },
]

const filterButtons: { label: string; value: ProjectCategory }[] = [
  { label: "All", value: "all" },
  { label: "Labs", value: "labs" },
  { label: "Scripts", value: "scripts" },
  { label: "Analysis", value: "analysis" },
]

const colorClasses = {
  primary: {
    bg: "bg-primary/10",
    text: "text-primary",
    border: "border-primary/30",
    hover: "hover:border-primary/50",
    glow: "group-hover:shadow-[0_0_20px_rgba(74,222,128,0.3)]",
  },
  accent: {
    bg: "bg-accent/10",
    text: "text-accent",
    border: "border-accent/30",
    hover: "hover:border-accent/50",
    glow: "group-hover:shadow-[0_0_20px_rgba(132,204,22,0.3)]",
  },
  cyan: {
    bg: "bg-neon-cyan/10",
    text: "text-neon-cyan",
    border: "border-neon-cyan/30",
    hover: "hover:border-neon-cyan/50",
    glow: "group-hover:shadow-[0_0_20px_rgba(34,211,238,0.3)]",
  },
}

export function ProjectsSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [activeFilter, setActiveFilter] = useState<ProjectCategory>("all")
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const filteredProjects =
    activeFilter === "all"
      ? projects
      : projects.filter((project) => project.category === activeFilter)

  return (
    <section
      ref={sectionRef}
      id="projects"
      className="py-20 md:py-32 relative overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-1/4 left-0 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-0 w-72 h-72 bg-accent/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section header */}
        <div
          className={`text-center mb-12 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Security <span className="text-primary">Projects</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full mb-6" />
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Hands-on cybersecurity labs and tools demonstrating practical security skills
          </p>
        </div>

        {/* Filter buttons */}
        <div
          className={`flex flex-wrap justify-center gap-3 mb-12 transition-all duration-700 delay-200 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          {filterButtons.map((button) => (
            <Button
              key={button.value}
              variant={activeFilter === button.value ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveFilter(button.value)}
              className={`transition-all duration-300 ${
                activeFilter === button.value
                  ? "bg-primary text-primary-foreground"
                  : "border-border hover:border-primary/50"
              }`}
            >
              {button.label}
            </Button>
          ))}
        </div>

        {/* Projects grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {filteredProjects.map((project, index) => {
            const colors = colorClasses[project.color]
            return (
              <Card
                key={project.id}
                className={`group bg-card/50 border-border ${colors.hover} transition-all duration-500 hover:-translate-y-2 ${colors.glow} ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${300 + index * 100}ms` }}
              >
                <CardHeader className="pb-2">
                  {/* Project icon/screenshot placeholder */}
                  <div className={`w-full aspect-video rounded-lg ${colors.bg} flex items-center justify-center mb-4 overflow-hidden relative`}>
                    <project.icon className={`w-12 h-12 ${colors.text}`} />
                    <div className={`absolute inset-0 ${colors.bg} opacity-0 group-hover:opacity-50 transition-opacity`} />
                  </div>
                  <h3 className="text-lg font-semibold">{project.title}</h3>
                </CardHeader>
                <CardContent className="pb-4">
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <Badge
                        key={tag}
                        variant="secondary"
                        className={`${colors.bg} ${colors.text} border-0 text-xs`}
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="gap-2 pt-0">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex-1 hover:bg-primary/10 hover:text-primary"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    Code
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex-1 hover:bg-primary/10 hover:text-primary"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Demo
                  </Button>
                </CardFooter>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
