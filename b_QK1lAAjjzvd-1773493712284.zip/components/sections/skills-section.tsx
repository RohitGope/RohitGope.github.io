"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Bug,
  FileSearch,
  FileText,
  Lightbulb,
  Shield,
  Activity,
  AlertTriangle,
  Search,
  Terminal,
  Award,
} from "lucide-react"

const qaSkills = [
  { icon: Bug, name: "Test Automation", description: "Automated testing frameworks and CI/CD integration" },
  { icon: FileSearch, name: "Defect Management", description: "Tracking, prioritizing, and resolving software defects" },
  { icon: FileText, name: "Documentation", description: "Comprehensive test plans and technical documentation" },
  { icon: Lightbulb, name: "Problem Solving", description: "Root cause analysis and systematic debugging" },
]

const cybersecuritySkills = [
  { icon: Activity, name: "SIEM Tools", description: "Splunk, ELK Stack for security monitoring" },
  { icon: Search, name: "Log Analysis", description: "Parsing and analyzing security logs and events" },
  { icon: AlertTriangle, name: "Incident Response", description: "Detecting, analyzing, and responding to threats" },
  { icon: Shield, name: "Vulnerability Assessment", description: "Nessus, OpenVAS for security scanning" },
  { icon: Terminal, name: "Python Scripting", description: "Automation scripts for security tasks" },
]

export function SkillsSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [flippedCard, setFlippedCard] = useState<string | null>(null)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const handleCardClick = (cardId: string) => {
    setFlippedCard(flippedCard === cardId ? null : cardId)
  }

  return (
    <section
      ref={sectionRef}
      id="skills"
      className="py-20 md:py-32 bg-secondary/30 relative overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,var(--neon-green)_0%,transparent_25%)] opacity-5" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,var(--neon-lime)_0%,transparent_25%)] opacity-5" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Skills <span className="text-primary">Matrix</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full mb-6" />
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Click on any skill card to see more details
          </p>
        </div>

        {/* Security+ Badge */}
        <div
          className={`flex justify-center mb-12 transition-all duration-700 delay-200 ${
            isVisible ? "opacity-100 scale-100" : "opacity-0 scale-90"
          }`}
        >
          <div className="relative group">
            <div className="flex items-center gap-3 px-6 py-4 rounded-xl bg-card border border-primary/30 hover:border-primary transition-colors">
              <Award className="w-8 h-8 text-primary" />
              <div>
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 mb-1">
                  Certified
                </Badge>
                <p className="font-bold text-lg">CompTIA Security+</p>
              </div>
            </div>
            <div className="absolute -inset-1 bg-primary/20 rounded-xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity -z-10" />
          </div>
        </div>

        {/* Skills grid */}
        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* QA Skills Column */}
          <div
            className={`transition-all duration-700 delay-300 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
            }`}
          >
            <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Bug className="w-5 h-5 text-accent" />
              <span>QA Skills</span>
            </h3>
            <div className="grid gap-4">
              {qaSkills.map((skill, index) => (
                <Card
                  key={skill.name}
                  className={`group cursor-pointer bg-card/50 border-border hover:border-accent/50 transition-all duration-300 hover:-translate-y-1 overflow-hidden ${
                    flippedCard === `qa-${skill.name}` ? "ring-2 ring-accent" : ""
                  }`}
                  style={{ transitionDelay: `${400 + index * 100}ms` }}
                  onClick={() => handleCardClick(`qa-${skill.name}`)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0 group-hover:bg-accent/20 transition-colors">
                        <skill.icon className="w-5 h-5 text-accent" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold mb-1">{skill.name}</h4>
                        <p
                          className={`text-sm text-muted-foreground transition-all duration-300 ${
                            flippedCard === `qa-${skill.name}`
                              ? "max-h-20 opacity-100"
                              : "max-h-0 opacity-0 overflow-hidden"
                          }`}
                        >
                          {skill.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Cybersecurity Skills Column */}
          <div
            className={`transition-all duration-700 delay-500 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
            }`}
          >
            <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              <span>Cybersecurity Skills</span>
            </h3>
            <div className="grid gap-4">
              {cybersecuritySkills.map((skill, index) => (
                <Card
                  key={skill.name}
                  className={`group cursor-pointer bg-card/50 border-border hover:border-primary/50 transition-all duration-300 hover:-translate-y-1 overflow-hidden ${
                    flippedCard === `cyber-${skill.name}` ? "ring-2 ring-primary" : ""
                  }`}
                  style={{ transitionDelay: `${600 + index * 100}ms` }}
                  onClick={() => handleCardClick(`cyber-${skill.name}`)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                        <skill.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold mb-1">{skill.name}</h4>
                        <p
                          className={`text-sm text-muted-foreground transition-all duration-300 ${
                            flippedCard === `cyber-${skill.name}`
                              ? "max-h-20 opacity-100"
                              : "max-h-0 opacity-0 overflow-hidden"
                          }`}
                        >
                          {skill.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
