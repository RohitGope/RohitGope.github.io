"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Calendar, Clock, ArrowRight, Search } from "lucide-react"

interface BlogPost {
  id: string
  title: string
  excerpt: string
  date: string
  readTime: string
  tags: string[]
  image?: string
}

const blogPosts: BlogPost[] = [
  {
    id: "siem-journey",
    title: "My Journey into SIEM: Getting Started with Splunk",
    excerpt: "Exploring the fundamentals of Security Information and Event Management, and how I set up my first Splunk instance for log analysis.",
    date: "March 10, 2026",
    readTime: "5 min read",
    tags: ["SIEM", "Splunk", "Learning"],
  },
  {
    id: "qa-to-security",
    title: "From QA to Cybersecurity: Transferable Skills",
    excerpt: "How my background in Quality Assurance has prepared me for a career in cybersecurity, and the surprising overlaps between both fields.",
    date: "February 28, 2026",
    readTime: "4 min read",
    tags: ["Career", "QA", "Skills"],
  },
  {
    id: "tryhackme-writeup",
    title: "TryHackMe SOC Level 1 Path Review",
    excerpt: "A comprehensive review of the TryHackMe SOC Level 1 learning path, including key takeaways and practical tips for beginners.",
    date: "February 15, 2026",
    readTime: "7 min read",
    tags: ["TryHackMe", "SOC", "Review"],
  },
  {
    id: "python-security",
    title: "Python for Security: Building Your First Log Parser",
    excerpt: "Step-by-step guide to creating a simple but effective log parsing tool using Python, perfect for aspiring SOC analysts.",
    date: "January 30, 2026",
    readTime: "6 min read",
    tags: ["Python", "Automation", "Tutorial"],
  },
  {
    id: "incident-response",
    title: "Understanding Incident Response Frameworks",
    excerpt: "Breaking down the NIST Incident Response framework and how it applies to real-world security operations.",
    date: "January 15, 2026",
    readTime: "5 min read",
    tags: ["IR", "NIST", "Frameworks"],
  },
  {
    id: "wireshark-basics",
    title: "Wireshark 101: Packet Analysis for Beginners",
    excerpt: "An introduction to network packet analysis using Wireshark, covering basic filters and common use cases.",
    date: "January 5, 2026",
    readTime: "8 min read",
    tags: ["Wireshark", "Network", "Tutorial"],
  },
]

const allTags = Array.from(new Set(blogPosts.flatMap((post) => post.tags)))

export function BlogSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [displayCount, setDisplayCount] = useState(3)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    )
  }

  const filteredPosts = blogPosts.filter((post) => {
    const matchesSearch =
      searchQuery === "" ||
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesTags =
      selectedTags.length === 0 ||
      selectedTags.some((tag) => post.tags.includes(tag))

    return matchesSearch && matchesTags
  })

  const displayedPosts = filteredPosts.slice(0, displayCount)
  const hasMore = displayCount < filteredPosts.length

  return (
    <section
      ref={sectionRef}
      id="blog"
      className="py-20 md:py-32 relative overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section header */}
        <div
          className={`text-center mb-12 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Blog & <span className="text-primary">Insights</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full mb-6" />
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Documenting my cybersecurity learning journey, tool explorations, and case studies
          </p>
        </div>

        {/* Search and filters */}
        <div
          className={`max-w-4xl mx-auto mb-10 transition-all duration-700 delay-200 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          {/* Search bar */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search posts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-card/50 border-border focus:border-primary"
            />
          </div>

          {/* Tag filters */}
          <div className="flex flex-wrap gap-2 justify-center">
            {allTags.map((tag) => (
              <Button
                key={tag}
                variant={selectedTags.includes(tag) ? "default" : "outline"}
                size="sm"
                onClick={() => toggleTag(tag)}
                className={`transition-all duration-300 ${
                  selectedTags.includes(tag)
                    ? "bg-primary text-primary-foreground"
                    : "border-border hover:border-primary/50"
                }`}
              >
                {tag}
              </Button>
            ))}
          </div>
        </div>

        {/* Blog posts grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {displayedPosts.map((post, index) => (
            <Card
              key={post.id}
              className={`group bg-card/50 border-border hover:border-primary/50 transition-all duration-500 hover:-translate-y-2 overflow-hidden ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: `${300 + index * 100}ms` }}
            >
              {/* Image placeholder with zoom effect */}
              <div className="relative aspect-video bg-secondary overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-neon-green/20 via-neon-lime/10 to-neon-cyan/20 flex items-center justify-center">
                  <span className="text-4xl font-bold text-primary/30">
                    {post.title[0]}
                  </span>
                </div>
                <div className="absolute inset-0 bg-background/20 group-hover:bg-transparent transition-all duration-300 group-hover:scale-105" />
              </div>

              <CardHeader className="pb-2">
                <div className="flex items-center gap-4 text-xs text-muted-foreground mb-2">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {post.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {post.readTime}
                  </span>
                </div>
                <h3 className="font-semibold text-lg leading-tight group-hover:text-primary transition-colors">
                  {post.title}
                </h3>
              </CardHeader>

              <CardContent className="pb-4">
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {post.excerpt}
                </p>
              </CardContent>

              <CardFooter className="pt-0 flex items-center justify-between">
                <div className="flex flex-wrap gap-1">
                  {post.tags.slice(0, 2).map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className="text-xs bg-primary/10 text-primary border-0"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-primary hover:text-primary hover:bg-primary/10"
                >
                  Read
                  <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Load more button */}
        {hasMore && (
          <div
            className={`text-center mt-10 transition-all duration-700 delay-500 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <Button
              variant="outline"
              onClick={() => setDisplayCount((prev) => prev + 3)}
              className="border-primary/30 hover:bg-primary/10 hover:border-primary"
            >
              Load More Posts
            </Button>
          </div>
        )}

        {/* No results message */}
        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              No posts found matching your criteria.
            </p>
          </div>
        )}
      </div>
    </section>
  )
}
