import type { Metadata, Viewport } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-sans',
});

const jetbrainsMono = JetBrains_Mono({ 
  subsets: ["latin"],
  variable: '--font-mono',
});

export const metadata: Metadata = {
  title: 'Rohit Gope | SOC Analyst & Cybersecurity Professional',
  description: 'QA Specialist transitioning into SOC Analyst role. Leveraging QA precision to defend against cyber threats. CompTIA Security+ certified.',
  keywords: ['SOC Analyst', 'Cybersecurity', 'QA Specialist', 'Security+', 'SIEM', 'Incident Response'],
  authors: [{ name: 'Rohit Gope' }],
  openGraph: {
    title: 'Rohit Gope | SOC Analyst & Cybersecurity Professional',
    description: 'QA Specialist transitioning into SOC Analyst role. Leveraging QA precision to defend against cyber threats.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#4ade80',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
